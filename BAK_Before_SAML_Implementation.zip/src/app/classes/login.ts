export class loginPrams {
  strLoginName: string;
  strPassword: string;

}
