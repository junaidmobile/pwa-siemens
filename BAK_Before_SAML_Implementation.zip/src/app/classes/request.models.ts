export class Requestmodels {
  public RequestObject: any;
  public RequestUrl: string;
}
