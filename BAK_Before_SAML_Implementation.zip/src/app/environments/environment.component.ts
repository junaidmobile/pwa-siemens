export const environment = {
  production: false,
  //ApiURL: 'https://eccportal.kalelogistics.com/'
  ApiURL: 'https://eccportal-login.siemens-healthineers.com/',
  //ApiURL: 'http://localhost/ECC/'
  MainURL : "https://eccportal-login.siemens-healthineers.com/"

};
