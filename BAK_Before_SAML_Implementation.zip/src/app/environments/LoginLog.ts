export class LoginLog {
  public LoginName: string;
  public LoginPassword: string;
  public Logid:number;
  public IpAddress:string;
  public IpCity:string;
  public IpCountry: string;
  public IpOrg: string;
  public IsLogin: boolean;
  public LoginTime: Date;
  public IsLogout: boolean;
  public LogoutTime: Date;
  public IsOAuth: boolean;
     
}

export class KeyValuesCode {
   
  KeyValue: any;
  UserKey: any;

}
